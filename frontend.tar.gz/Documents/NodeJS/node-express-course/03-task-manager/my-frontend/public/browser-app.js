const taskInput = document.querySelector(".task-input");
const submitBtn = document.querySelector(".submit-btn");
const formAlert = document.querySelector(".form-alert");
const tasksList = document.querySelector(".tasks");

const showTasks = async () => {
    try{
        const { data }  = await axios.get('/api/v1/tasks');
        for (let i =0 ; i< data.tasks.length; i++){
            const id = data.tasks[i]._id;
            const elem = document.createElement('div');
            elem.className = "single-task";
            const h5 = document.createElement('h5');
            h5.innerHTML = data.tasks[i].name;
            const links = document.createElement("div");
            links.className = "task-links";
            const edit_link = document.createElement('a');
            edit_link.href =`task.html?${id}`;
            edit_link.className = "edit-link";
            const del_button = document.createElement('button');
            del_button.id = id;
            del_button.className = "delete-btn";
            links.appendChild(edit_link);
            links.appendChild(del_button);
            elem.appendChild(h5);
            elem.append(links);
            tasksList.appendChild(elem);
        } 
    } catch(err){
        console.log(err)
    }
}

showTasks();

submitBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const name = taskInput.value;

    const addTask = async() => {
        try{
            await axios.post('/api/v1/tasks', { name });
            console.log("Done");
        } catch(err){
            formAlert.innerHTML="An error occured."
        }
    }
    addTask()
})